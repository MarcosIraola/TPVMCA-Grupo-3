#!/bin/bash

# AYUDA
if [[ "$1" == "-help" ]]; then
  echo ""
  echo ""
  echo "Uso: $0 <directorio_origen> <directorio_destino>"
  echo "Este script genera un backup del directorio indicado,"
  echo "guardándolo en un archivo comprimido con nombre <nombre_bkp_YYYYMMDD.tar.gz>."
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo ""
  echo ""
  exit 0
fi

# VALIDAR ARGUMENTOS
if [ $# -ne 2 ]; then
  echo ""
  echo "Error: se requieren exactamente 2 argumentos."
  echo "Usá: $0 -help para ver cómo se usa."
  echo ""
  exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# VALIDAR DIRECTORIOS
if [ ! -d "$ORIGEN" ]; then
  ""
  echo "Error: el directorio de origen '$ORIGEN' no existe."
  echo ""
  exit 1
fi

if [ ! -d "$DESTINO" ]; then
  echo ""
  echo "Error: el directorio de destino '$DESTINO' no existe."
  echo ""
  exit 1
fi

# FORMAR NOMBRE DE BACKUP
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# CREAR BACKUP
tar czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup generado: $DESTINO/$ARCHIVO"

